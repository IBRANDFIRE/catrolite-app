# Supported bricks / scripts

Implemented in `engine/BrickInterpreter.kt`. All of these are the ones your
uploaded `game_5.newtrobat` actually uses, confirmed by scanning its `code.xml`.

## Scripts (triggers)
| Type | Behaviour |
|---|---|
| `StartScript` | Runs automatically when the game launches |
| `WhenScript` | Runs when the sprite is tapped on screen |
| `BroadcastScript` | Runs when a matching `BroadcastBrick` message fires |

## Bricks
| Type | Behaviour |
|---|---|
| `PlaceAtBrick` | Set sprite x/y position |
| `MoveNStepsBrick` | Move forward N steps in current facing direction |
| `TurnLeftBrick` / `TurnRightBrick` | Rotate sprite |
| `PointInDirectionBrick` | Set absolute rotation |
| `SetLookBrick` | Switch costume by name |
| `SetLookByIndexBrick` | Switch costume by index |
| `SetSizeToBrick` / `ChangeSizeByNBrick` | Scale sprite |
| `SetTransparencyBrick` / `ChangeTransparencyByNBrick` | Opacity |
| `ChangeBrightnessByNBrick` | Tracked but not yet rendered (no brightness shader applied) |
| `ShowBrick` / `HideBrick` | Visibility |
| `SetVariableBrick` / `ChangeVariableBrick` | Per-sprite variables |
| `WaitBrick` | Delay N seconds |
| `WaitUntilBrick` | Poll a condition until true |
| `ForeverBrick` | Infinite loop |
| `RepeatUntilBrick` | Loop until condition true |
| `IfLogicBeginBrick` / `IfThenLogicBeginBrick` | Conditional branch (if/else) |
| `BroadcastBrick` | Fire a message other sprites' `BroadcastScript`s can catch |

## Formula operators (`engine/FormulaEvaluator.kt`)
`PLUS, MINUS, MULT, DIVIDE, EQUAL, NOT_EQUAL, GREATER_THAN, SMALLER_THAN,
GREATER_OR_EQUAL, SMALLER_OR_EQUAL, LOGICAL_AND, LOGICAL_OR, LOGICAL_NOT`,
plus functions `ABS, ROUND, MAX, MIN`. Node types `NUMBER, STRING, USER_VARIABLE`.

## Not implemented (common ones you may hit in other game zips)
`PlaySoundBrick`, `WhenNfcBrick`, `IfOnEdgeBounceBrick`, physics bricks
(`SetPhysicsObjectTypeBrick`, `SetGravityBrick`, ...), list operations, custom
(user-defined) bricks, `GlideToBrick`, sensor formulas (accelerometer, GPS, etc.),
multiplayer/cast bricks. Adding one is generally: read its `code.xml` shape (grep
your zip's `code.xml` for `brick type="..."` like was done for this project),
add a `when` branch in `BrickInterpreter.kt`, done.
