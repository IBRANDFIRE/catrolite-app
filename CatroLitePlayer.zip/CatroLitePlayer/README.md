# Catro Lite Player

A minimal, from-scratch Android player for Catrobat-format projects (the format
used by "NewCatroid" / Pocket Code — `code.xml` + `Scene/images/...` inside a zip,
e.g. your `.newtrobat` files).

This is **not** the full Catrobat engine (that's a 10+ year, 100+ brick, multi-team
codebase — see `supported-bricks.md`). It's a compact interpreter covering the
~20 brick types your uploaded `game_5.newtrobat` actually uses: movement, rotation,
looks/costumes, variables, loops, if/else, wait, and broadcast messages. It's built
so you (or another dev, or another Claude session) can add more brick types later —
see "Extending" below.

## What's bundled

Your uploaded game is already placed at:
```
app/src/main/assets/bundled_game.newtrobat
```
It runs automatically on launch — no project picker screen, single game per APK
(this is the "white-label" behaviour you asked for).

## How to build

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open this folder (`CatroLitePlayer/`) as a project — File → Open.
3. Let Gradle sync (first time, Android Studio will download the Android SDK
   components + Gradle itself — this step needs internet).
4. Build → Build Bundle(s)/APK(s) → **Build APK(s)**.
5. Your installable APK appears in `app/build/outputs/apk/debug/app-debug.apk`
   (or `release/` for a signed release build).

No command line needed, but if you prefer it: `./gradlew assembleDebug`
(Android Studio will offer to generate the `gradlew` wrapper files for you the
first time you open the project, since this download step needs internet access
I didn't have available.)

## 32-bit / 64-bit support

This app is pure Kotlin — no native (C/C++) code — so it **already** runs on
32-bit (`armeabi-v7a`) and 64-bit (`arm64-v8a`) devices with zero extra work.
`app/build.gradle.kts` has explicit `abiFilters` set anyway, and `splits.abi.isEnable = false`
means Gradle produces **one universal APK** that installs on both. If you later
add a native library (a physics engine, an ad SDK with native code, etc.), this is
exactly where you'd need to double-check both `.so` variants are present.

## Shipping a different game

1. Replace `app/src/main/assets/bundled_game.newtrobat` with your other zip
   (keep the same filename, or update `bundledAssetName` in `MainActivity.kt`).
2. Change `applicationId`, app name (`strings.xml`), and icon
   (`res/drawable/ic_launcher.xml` is a placeholder — swap it for real art)
   if this is going out as its own store listing.
3. Rebuild.

## Known limitations (be aware before relying on this for a real release)

- **Single scene only.** Multi-scene projects (scene-switching) aren't wired up —
  only the first `<scene>` in `code.xml` runs.
- **No sound playback yet.** `Scene/sounds/` files aren't triggered (no `PlaySoundBrick`
  in your uploaded game, so it wasn't needed yet — see Extending).
- **No physics engine.** `physicsWidthArea`/`physicsHeightArea` and physics-based
  bricks aren't implemented.
- **~20 of 100+ Catrobat brick types supported** — see `supported-bricks.md` for
  the exact list and how to add more. Unsupported bricks are silently skipped
  rather than crashing, so a game using them will run, just missing that behaviour.
- **Formula support covers common cases** (arithmetic, comparisons, AND/OR, a
  few functions) — very advanced formulas (sensors, list operations, custom
  blocks) aren't evaluated yet.

## Extending

- Add a new brick: `engine/BrickInterpreter.kt`, add a `when` branch.
- Add a new formula operator/function: `engine/FormulaEvaluator.kt`.
- Add multi-scene support: `engine/StageEngine.kt` currently hardcodes
  `program.scenes.firstOrNull()`.
- Add sound: `MainActivity`/`GameStageView` would need a `SoundPool` or
  `MediaPlayer` wired to a new `PlaySoundBrick` case, reading from
  `<scene>/sounds/<fileName>`.
