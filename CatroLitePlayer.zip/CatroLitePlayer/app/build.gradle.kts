plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gamestudio.catrolite"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gamestudio.catrolite"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // This app is pure Kotlin/Java — no native (C/C++) code — so it already
        // runs on both 32-bit and 64-bit devices with zero extra config.
        // These lines are only needed if you later add a native library (.so files),
        // e.g. a physics engine or ad SDK that ships native code. Left in for that case.
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    // enable = false -> one universal APK containing both 32-bit and 64-bit support.
    // Set to true (and remove the line above) if you want Gradle to output a
    // separate, smaller APK per architecture instead (useful for direct APK distribution).
    splits {
        abi {
            isEnable = false
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
