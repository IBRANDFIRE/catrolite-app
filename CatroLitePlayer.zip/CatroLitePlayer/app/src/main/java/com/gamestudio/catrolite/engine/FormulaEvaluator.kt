package com.gamestudio.catrolite.engine

/**
 * Evaluates a Catrobat <formula> tree against a sprite's current variables.
 * Supports the operators/functions this player's supported bricks actually need.
 * Anything unrecognised falls back to 0 / "" instead of crashing, so playback continues.
 */
object FormulaEvaluator {

    fun evalNumber(node: FormulaNode?, sprite: SpriteModel): Double {
        val v = eval(node, sprite)
        return when (v) {
            is Double -> v
            is String -> v.toDoubleOrNull() ?: 0.0
            is Boolean -> if (v) 1.0 else 0.0
            else -> 0.0
        }
    }

    fun evalString(node: FormulaNode?, sprite: SpriteModel): String {
        val v = eval(node, sprite)
        return when (v) {
            is Double -> if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()
            else -> v?.toString() ?: ""
        }
    }

    fun evalBoolean(node: FormulaNode?, sprite: SpriteModel): Boolean {
        val v = eval(node, sprite)
        return when (v) {
            is Boolean -> v
            is Double -> v != 0.0
            is String -> v.isNotEmpty() && v != "0" && v != "false"
            else -> false
        }
    }

    private fun eval(node: FormulaNode?, sprite: SpriteModel): Any? {
        if (node == null) return null
        return when (node.type) {
            "NUMBER" -> node.value.toDoubleOrNull() ?: 0.0
            "STRING" -> node.value
            "USER_VARIABLE" -> sprite.variables[node.value]
            "OPERATOR" -> evalOperator(node, sprite)
            "FUNCTION" -> evalFunction(node, sprite)
            else -> node.value
        }
    }

    private fun evalOperator(node: FormulaNode, sprite: SpriteModel): Any {
        val op = node.value
        return when (op) {
            "PLUS" -> evalNumber(node.left, sprite) + evalNumber(node.right, sprite)
            "MINUS" -> evalNumber(node.left, sprite) - evalNumber(node.right, sprite)
            "MULT" -> evalNumber(node.left, sprite) * evalNumber(node.right, sprite)
            "DIVIDE" -> {
                val r = evalNumber(node.right, sprite)
                if (r == 0.0) 0.0 else evalNumber(node.left, sprite) / r
            }
            "EQUAL" -> equalsLoose(node, sprite)
            "NOT_EQUAL" -> !equalsLoose(node, sprite)
            "GREATER_THAN" -> evalNumber(node.left, sprite) > evalNumber(node.right, sprite)
            "SMALLER_THAN" -> evalNumber(node.left, sprite) < evalNumber(node.right, sprite)
            "GREATER_OR_EQUAL" -> evalNumber(node.left, sprite) >= evalNumber(node.right, sprite)
            "SMALLER_OR_EQUAL" -> evalNumber(node.left, sprite) <= evalNumber(node.right, sprite)
            "LOGICAL_AND" -> evalBoolean(node.left, sprite) && evalBoolean(node.right, sprite)
            "LOGICAL_OR" -> evalBoolean(node.left, sprite) || evalBoolean(node.right, sprite)
            "LOGICAL_NOT" -> !evalBoolean(node.left, sprite)
            else -> 0.0
        }
    }

    private fun equalsLoose(node: FormulaNode, sprite: SpriteModel): Boolean {
        val l = eval(node.left, sprite)
        val r = eval(node.right, sprite)
        val ln = (l as? Double) ?: (l as? String)?.toDoubleOrNull()
        val rn = (r as? Double) ?: (r as? String)?.toDoubleOrNull()
        if (ln != null && rn != null) return ln == rn
        return l?.toString() == r?.toString()
    }

    private fun evalFunction(node: FormulaNode, sprite: SpriteModel): Any {
        // Extend here for RAND, ABS, ROUND, etc. as your games need them.
        return when (node.value) {
            "ABS" -> Math.abs(evalNumber(node.left, sprite))
            "ROUND" -> Math.round(evalNumber(node.left, sprite)).toDouble()
            "MAX" -> Math.max(evalNumber(node.left, sprite), evalNumber(node.right, sprite))
            "MIN" -> Math.min(evalNumber(node.left, sprite), evalNumber(node.right, sprite))
            else -> 0.0
        }
    }
}
