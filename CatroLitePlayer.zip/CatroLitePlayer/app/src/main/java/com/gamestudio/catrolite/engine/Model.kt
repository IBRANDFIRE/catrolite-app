package com.gamestudio.catrolite.engine

/**
 * Generic tree node for any <brick> or nested block. Rather than hand-writing a
 * class per brick type (there are 100+ in the full Catrobat language), bricks are
 * represented generically here; BrickInterpreter.kt decides at runtime what each
 * "type" actually does. Unknown types are safely skipped instead of crashing.
 */
data class BrickNode(
    val type: String,
    val formulas: Map<String, FormulaNode> = emptyMap(), // keyed by <formula category="...">
    val userVariableName: String? = null,                // for Set/ChangeVariableBrick
    val children: Map<String, List<BrickNode>> = emptyMap() // e.g. "loopBricks", "ifBranchBricks", "elseBranchBricks"
)

data class FormulaNode(
    val type: String,          // NUMBER, STRING, OPERATOR, USER_VARIABLE, FUNCTION, SENSOR ...
    val value: String,
    val left: FormulaNode? = null,
    val right: FormulaNode? = null
)

data class ScriptNode(
    val type: String,          // StartScript, WhenScript, BroadcastScript ...
    val receivedMessage: String? = null, // for BroadcastScript
    val bricks: List<BrickNode>
)

data class LookModel(
    val name: String,
    val fileName: String
)

data class SoundModel(
    val name: String,
    val fileName: String
)

data class SpriteModel(
    val name: String,
    val looks: List<LookModel>,
    val sounds: List<SoundModel>,
    val scripts: List<ScriptNode>
) {
    // Runtime state (mutated during play, not part of the parsed file)
    var x: Float = 0f
    var y: Float = 0f
    var rotationDegrees: Float = 0f
    var sizePercent: Float = 100f
    var transparencyPercent: Float = 0f
    var brightnessPercent: Float = 100f
    var visible: Boolean = true
    var currentLookIndex: Int = 0
    val variables: MutableMap<String, Any?> = mutableMapOf()
}

data class SceneModel(
    val name: String,
    val sprites: List<SpriteModel>
)

data class ProgramModel(
    val name: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val scenes: List<SceneModel>
)
