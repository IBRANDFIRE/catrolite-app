package com.gamestudio.catrolite.engine

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Runs one ProgramModel: starts every sprite's StartScript, routes touches to
 * WhenScript ("when this sprite tapped"), and routes BroadcastBrick messages to
 * matching BroadcastScript scripts on every sprite.
 */
class StageEngine(val program: ProgramModel) {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val interpreter = BrickInterpreter(this)
    private val runningJobs = mutableListOf<Job>()

    // Single-scene support for this lite player; extend to switch scenes for multi-scene games.
    val activeScene: SceneModel = program.scenes.firstOrNull()
        ?: SceneModel("Scene", emptyList())

    fun start() {
        for (sprite in activeScene.sprites) {
            for (script in sprite.scripts) {
                if (script.type == "StartScript") {
                    runningJobs += scope.launch { interpreter.runScript(sprite, script) }
                }
            }
        }
    }

    fun onSpriteTapped(sprite: SpriteModel) {
        for (script in sprite.scripts) {
            if (script.type == "WhenScript") {
                runningJobs += scope.launch { interpreter.runScript(sprite, script) }
            }
        }
    }

    fun broadcast(message: String) {
        for (sprite in activeScene.sprites) {
            for (script in sprite.scripts) {
                if (script.type == "BroadcastScript" && script.receivedMessage == message) {
                    runningJobs += scope.launch { interpreter.runScript(sprite, script) }
                }
            }
        }
    }

    fun stop() {
        scope.coroutineContext[Job]?.cancel()
    }
}
