package com.gamestudio.catrolite.engine

import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.coroutines.coroutineContext
import kotlin.math.cos
import kotlin.math.sin

/**
 * Executes a sprite's bricks. Supported brick types are listed in supported-bricks.md.
 * Anything else is a no-op — the script keeps running instead of crashing, so partially
 * -supported games still play as far as they can.
 */
class BrickInterpreter(private val engine: StageEngine) {

    suspend fun runScript(sprite: SpriteModel, script: ScriptNode) {
        runBricks(sprite, script.bricks)
    }

    private suspend fun runBricks(sprite: SpriteModel, bricks: List<BrickNode>) {
        for (brick in bricks) {
            if (!coroutineContext.isActive) return
            runBrick(sprite, brick)
        }
    }

    private suspend fun runBrick(sprite: SpriteModel, brick: BrickNode) {
        when (brick.type) {
            "PlaceAtBrick" -> {
                sprite.x = numberFormula(brick, "X_POSITION", sprite)?.toFloat() ?: sprite.x
                sprite.y = numberFormula(brick, "Y_POSITION", sprite)?.toFloat() ?: sprite.y
            }
            "MoveNStepsBrick" -> {
                val steps = number(brick.formulas.values.firstOrNull(), sprite)
                val rad = Math.toRadians(sprite.rotationDegrees.toDouble())
                sprite.x += (steps * sin(rad)).toFloat()
                sprite.y += (steps * cos(rad)).toFloat()
            }
            "TurnLeftBrick" -> sprite.rotationDegrees -= number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "TurnRightBrick" -> sprite.rotationDegrees += number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "PointInDirectionBrick" -> sprite.rotationDegrees = number(brick.formulas.values.firstOrNull(), sprite).toFloat()

            "SetLookBrick" -> {
                // formula category VARIABLE holds the look name as a STRING
                val lookName = string(brick.formulas.values.firstOrNull(), sprite)
                val idx = sprite.looks.indexOfFirst { it.name == lookName }
                if (idx >= 0) sprite.currentLookIndex = idx
            }
            "SetLookByIndexBrick" -> {
                val idx = number(brick.formulas.values.firstOrNull(), sprite).toInt()
                if (sprite.looks.isNotEmpty()) sprite.currentLookIndex = idx.coerceIn(0, sprite.looks.size - 1)
            }

            "SetSizeToBrick" -> sprite.sizePercent = number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "ChangeSizeByNBrick" -> sprite.sizePercent += number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "SetTransparencyBrick" -> sprite.transparencyPercent = number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "ChangeTransparencyByNBrick" -> sprite.transparencyPercent += number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "ChangeBrightnessByNBrick" -> sprite.brightnessPercent += number(brick.formulas.values.firstOrNull(), sprite).toFloat()
            "ShowBrick" -> sprite.visible = true
            "HideBrick" -> sprite.visible = false

            "SetVariableBrick" -> {
                brick.userVariableName?.let { name ->
                    sprite.variables[name] = rawValue(brick.formulas.values.firstOrNull(), sprite)
                }
            }
            "ChangeVariableBrick" -> {
                brick.userVariableName?.let { name ->
                    val current = (sprite.variables[name] as? Double) ?: (sprite.variables[name] as? String)?.toDoubleOrNull() ?: 0.0
                    sprite.variables[name] = current + number(brick.formulas.values.firstOrNull(), sprite)
                }
            }

            "WaitBrick" -> {
                val seconds = number(brick.formulas.values.firstOrNull(), sprite)
                delay((seconds * 1000).toLong().coerceAtLeast(0))
            }
            "WaitUntilBrick" -> {
                val condition = brick.formulas.values.firstOrNull()
                while (coroutineContext.isActive && !FormulaEvaluator.evalBoolean(condition, sprite)) {
                    delay(16)
                }
            }

            "ForeverBrick" -> {
                val loop = brick.children["loopBricks"].orEmpty()
                while (coroutineContext.isActive) {
                    runBricks(sprite, loop)
                    delay(1) // yield so this doesn't starve the render loop
                }
            }
            "RepeatUntilBrick" -> {
                val condition = brick.formulas.values.firstOrNull()
                val loop = brick.children["loopBricks"].orEmpty()
                while (coroutineContext.isActive && !FormulaEvaluator.evalBoolean(condition, sprite)) {
                    runBricks(sprite, loop)
                    delay(1)
                }
            }
            "IfLogicBeginBrick", "IfThenLogicBeginBrick" -> {
                val condition = brick.formulas.values.firstOrNull()
                if (FormulaEvaluator.evalBoolean(condition, sprite)) {
                    runBricks(sprite, brick.children["ifBranchBricks"].orEmpty())
                } else {
                    runBricks(sprite, brick.children["elseBranchBricks"].orEmpty())
                }
            }

            "BroadcastBrick" -> {
                val message = brick.formulas["BROADCAST_MESSAGE"]?.value
                if (message != null) engine.broadcast(message)
            }

            else -> {
                // Unsupported brick — see supported-bricks.md to add it.
            }
        }
    }

    private fun numberFormula(brick: BrickNode, category: String, sprite: SpriteModel): Double? =
        brick.formulas[category]?.let { FormulaEvaluator.evalNumber(it, sprite) }

    private fun number(node: FormulaNode?, sprite: SpriteModel): Double = FormulaEvaluator.evalNumber(node, sprite)
    private fun string(node: FormulaNode?, sprite: SpriteModel): String = FormulaEvaluator.evalString(node, sprite)
    private fun rawValue(node: FormulaNode?, sprite: SpriteModel): Any? = when (node?.type) {
        "NUMBER" -> node.value.toDoubleOrNull() ?: 0.0
        else -> if (node != null) FormulaEvaluator.evalString(node, sprite) else null
    }
}
