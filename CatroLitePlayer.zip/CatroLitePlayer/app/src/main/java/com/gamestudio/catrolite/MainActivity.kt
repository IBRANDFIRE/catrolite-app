package com.gamestudio.catrolite

import android.app.Activity
import android.os.Bundle
import com.gamestudio.catrolite.engine.ProjectParser
import com.gamestudio.catrolite.engine.StageEngine
import com.gamestudio.catrolite.ui.GameStageView
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    // This is the ONLY thing you change to ship a different game with this template:
    // put your .newtrobat / .catrobat zip in app/src/main/assets/ under this exact name.
    private val bundledAssetName = "bundled_game.newtrobat"

    private var engine: StageEngine? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val projectDir = File(filesDir, "current_project")
        if (!projectDir.exists() || projectDir.listFiles().isNullOrEmpty()) {
            projectDir.mkdirs()
            unzipAssetTo(bundledAssetName, projectDir)
        }

        val codeXml = File(projectDir, "code.xml")
        val program = ProjectParser.parse(codeXml)

        val stageEngine = StageEngine(program)
        engine = stageEngine

        val sceneFolderName = program.scenes.firstOrNull()?.name ?: "Scene"
        setContentView(GameStageView(this, stageEngine, projectDir, sceneFolderName))

        stageEngine.start()
    }

    override fun onDestroy() {
        engine?.stop()
        super.onDestroy()
    }

    private fun unzipAssetTo(assetName: String, targetDir: File) {
        assets.open(assetName).use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val outFile = File(targetDir, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { out -> zip.copyTo(out) }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
    }
}
