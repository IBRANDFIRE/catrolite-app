package com.gamestudio.catrolite.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.gamestudio.catrolite.engine.SpriteModel
import com.gamestudio.catrolite.engine.StageEngine
import java.io.File

/**
 * Renders the current scene's sprites at their live (x, y, rotation, size) state,
 * mapping Catrobat's coordinate system (0,0 = screen centre, +y = up) onto the
 * View's pixel space (0,0 = top-left, +y = down). Also detects taps on a sprite's
 * current look bounds and forwards them to StageEngine.onSpriteTapped().
 */
class GameStageView(
    context: Context,
    private val engine: StageEngine,
    private val projectDir: File,
    private val sceneFolderName: String
) : View(context) {

    private val bitmapCache = mutableMapOf<String, Bitmap?>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val backgroundPaint = Paint().apply { color = Color.BLACK }

    init {
        // Redraw continuously so sprite movement driven by the interpreter is visible.
        postInvalidateLoop()
    }

    private fun postInvalidateLoop() {
        postInvalidate()
        postDelayed({ postInvalidateLoop() }, 16)
    }

    private fun bitmapFor(fileName: String): Bitmap? {
        return bitmapCache.getOrPut(fileName) {
            val file = File(projectDir, "$sceneFolderName/images/$fileName")
            if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)

        val scaleX = width.toFloat() / engine.program.screenWidth
        val scaleY = height.toFloat() / engine.program.screenHeight

        for (sprite in engine.activeScene.sprites) {
            if (!sprite.visible) continue
            val look = sprite.looks.getOrNull(sprite.currentLookIndex) ?: continue
            val bitmap = bitmapFor(look.fileName) ?: continue

            // Catrobat coords: origin at screen centre, +y up. Convert to canvas pixels.
            val px = width / 2f + sprite.x * scaleX
            val py = height / 2f - sprite.y * scaleY

            val scale = sprite.sizePercent / 100f
            paint.alpha = (255 * (1f - (sprite.transparencyPercent.coerceIn(0f, 100f) / 100f))).toInt()

            val matrix = Matrix()
            matrix.postTranslate(-bitmap.width / 2f, -bitmap.height / 2f)
            matrix.postScale(scale * scaleX, scale * scaleY)
            matrix.postRotate(sprite.rotationDegrees)
            matrix.postTranslate(px, py)

            canvas.drawBitmap(bitmap, matrix, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val scaleX = width.toFloat() / engine.program.screenWidth
            val scaleY = height.toFloat() / engine.program.screenHeight

            // Hit-test in reverse draw order (topmost sprite first).
            for (sprite in engine.activeScene.sprites.asReversed()) {
                if (!sprite.visible) continue
                val look = sprite.looks.getOrNull(sprite.currentLookIndex) ?: continue
                val bitmap = bitmapCache[look.fileName] ?: continue

                val px = width / 2f + sprite.x * scaleX
                val py = height / 2f - sprite.y * scaleY
                val halfW = (bitmap.width * (sprite.sizePercent / 100f) * scaleX) / 2f
                val halfH = (bitmap.height * (sprite.sizePercent / 100f) * scaleY) / 2f

                if (event.x in (px - halfW)..(px + halfW) && event.y in (py - halfH)..(py + halfH)) {
                    engine.onSpriteTapped(sprite)
                    return true
                }
            }
        }
        return true
    }
}
