package com.gamestudio.catrolite.engine

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Parses a Catrobat project's code.xml into the Model.kt data classes.
 * Only reads what's needed to run the sprites/scripts described in
 * <supported-bricks.md> — unrecognised tags are simply ignored rather
 * than causing a crash, so new/unsupported bricks degrade gracefully.
 */
object ProjectParser {

    fun parse(codeXmlFile: File): ProgramModel {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(codeXmlFile)
        doc.documentElement.normalize()

        val header = firstChildElement(doc.documentElement, "header")
        val programName = textOf(header, "programName").ifBlank { "Untitled" }
        val screenWidth = textOf(header, "screenWidth").toIntOrNull() ?: 720
        val screenHeight = textOf(header, "screenHeight").toIntOrNull() ?: 1280

        val scenesEl = firstChildElement(doc.documentElement, "scenes")
        val scenes = childElements(scenesEl, "scene").map { parseScene(it) }

        return ProgramModel(programName, screenWidth, screenHeight, scenes)
    }

    private fun parseScene(sceneEl: Element): SceneModel {
        val name = textOf(sceneEl, "n").ifBlank { textOf(sceneEl, "name").ifBlank { "Scene" } }
        val objectListEl = firstChildElement(sceneEl, "objectList")
        val sprites = childElements(objectListEl, "object").map { parseSprite(it) }
        return SceneModel(name, sprites)
    }

    private fun parseSprite(objEl: Element): SpriteModel {
        val name = objEl.getAttribute("name").ifBlank { "sprite" }

        val looks = childElements(firstChildElement(objEl, "lookList"), "look").map {
            LookModel(
                name = it.getAttribute("name"),
                fileName = it.getAttribute("fileName")
            )
        }
        val sounds = childElements(firstChildElement(objEl, "soundList"), "sound").map {
            SoundModel(
                name = it.getAttribute("name"),
                fileName = it.getAttribute("fileName")
            )
        }
        val scripts = childElements(firstChildElement(objEl, "scriptList"), "script").map { parseScript(it) }

        return SpriteModel(name, looks, sounds, scripts)
    }

    private fun parseScript(scriptEl: Element): ScriptNode {
        val type = scriptEl.getAttribute("type").ifBlank { "StartScript" }
        val message = textOf(scriptEl, "receivedMessage").ifBlank { null }
        // Bricks sit inside a <brickList> wrapper directly under <script>.
        val brickListEl = firstChildElement(scriptEl, "brickList")
        val bricks = childElements(brickListEl, "brick").map { parseBrick(it) }
        return ScriptNode(type, message, bricks)
    }

    private fun parseBrick(brickEl: Element): BrickNode {
        val type = brickEl.getAttribute("type")

        val formulas = mutableMapOf<String, FormulaNode>()

        // BroadcastBrick (and similar) store their message as a plain text tag
        // rather than inside <formulaList>, so surface it as a synthetic STRING formula.
        val broadcastMsg = textOf(brickEl, "broadcastMessage")
        if (broadcastMsg.isNotBlank()) {
            formulas["BROADCAST_MESSAGE"] = FormulaNode("STRING", broadcastMsg)
        }
        val formulaListEl = firstChildElement(brickEl, "formulaList")
        if (formulaListEl != null) {
            for (formulaEl in childElements(formulaListEl, "formula")) {
                val category = formulaEl.getAttribute("category").ifBlank { "DEFAULT" }
                formulas[category] = parseFormula(formulaEl)
            }
        }

        var userVariableName: String? = null
        val userVarEl = firstChildElement(brickEl, "userVariable")
        if (userVarEl != null) {
            // nested: <userVariable><userVariable><default><name>...</name></default></userVariable></userVariable>
            val nameNode = findDescendant(userVarEl, "name")
            userVariableName = nameNode?.textContent?.trim()
        }

        // Generic nested-brick containers used by control-flow bricks
        val childContainers = listOf("loopBricks", "ifBranchBricks", "elseBranchBricks")
        val children = mutableMapOf<String, List<BrickNode>>()
        for (containerName in childContainers) {
            val containerEl = firstChildElement(brickEl, containerName)
            if (containerEl != null) {
                children[containerName] = childElements(containerEl, "brick").map { parseBrick(it) }
            }
        }

        return BrickNode(type, formulas, userVariableName, children)
    }

    private fun parseFormula(formulaEl: Element): FormulaNode {
        val type = textOf(formulaEl, "type").ifBlank { "NUMBER" }
        val value = textOf(formulaEl, "value")
        val leftEl = firstChildElement(formulaEl, "leftChild")
        val rightEl = firstChildElement(formulaEl, "rightChild")
        val left = leftEl?.let { parseFormula(it) }
        val right = rightEl?.let { parseFormula(it) }
        return FormulaNode(type, value, left, right)
    }

    // ---- small DOM helpers ----

    private fun firstChildElement(parent: Element?, tag: String): Element? {
        if (parent == null) return null
        val nl = parent.getElementsByTagName(tag)
        for (i in 0 until nl.length) {
            val n = nl.item(i)
            if (n is Element && n.parentNode === parent) return n
        }
        return null
    }

    private fun childElements(parent: Element?, tag: String): List<Element> {
        if (parent == null) return emptyList()
        val result = mutableListOf<Element>()
        val nl = parent.childNodes
        for (i in 0 until nl.length) {
            val n = nl.item(i)
            if (n is Element && n.tagName == tag) result.add(n)
        }
        return result
    }

    private fun textOf(parent: Element?, tag: String): String {
        val el = parent?.let { firstChildElement(it, tag) } ?: return ""
        return el.textContent?.trim() ?: ""
    }

    private fun findDescendant(root: Element, tag: String): Node? {
        val nl = root.getElementsByTagName(tag)
        return if (nl.length > 0) nl.item(0) else null
    }
}
